# TEXTO BARBEARIA ALURA

A Pen created on CodePen.io. Original URL: [https://codepen.io/joaovitorjosue/pen/PoQzbXM](https://codepen.io/joaovitorjosue/pen/PoQzbXM).

